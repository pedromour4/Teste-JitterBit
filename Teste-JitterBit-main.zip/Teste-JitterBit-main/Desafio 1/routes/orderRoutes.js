const express = require('express');
const router = express.Router();
const Order = require('../models/order');

// Criar um novo pedido
router.post('/order', async (req, res) => {
    const { numeroPedido, valorTotal, dataCriacao, items } = req.body;
    const transformedItems = items.map(item => ({
        productId: parseInt(item.idItem),
        quantity: item.quantidadeItem,
        price: item.valorItem,
    }));

    const newOrder = new Order({
        orderId: numeroPedido,
        value: valorTotal,
        creationDate: new Date(dataCriacao),
        items: transformedItems,
    });

    try {
        await newOrder.save();
        res.status(201).send(newOrder);
    } catch (error) {
        res.status(400).send(error);
    }
});

// Obter os dados do pedido
router.get('/order/:orderId', async (req, res) => {
    const { orderId } = req.params;
    try {
        const order = await Order.findOne({ orderId });
        if (!order) return res.status(404).send('Order not found');
        res.send(order);
    } catch (error) {
        res.status(400).send(error);
    }
});

// Listar todos os pedidos
router.get('/order/list', async (req, res) => {
    try {
        const orders = await Order.find({});
        res.send(orders);
    } catch (error) {
        res.status(400).send(error);
    }
});

// Atualizar o pedido
router.put('/order/:orderId', async (req, res) => {
    const { orderId } = req.params;
    const { valorTotal, items } = req.body;
    const transformedItems = items.map(item => ({
        productId: parseInt(item.idItem),
        quantity: item.quantidadeItem,
        price: item.valorItem,
    }));

    try {
        const order = await Order.findOneAndUpdate(
            { orderId },
            { value: valorTotal, items: transformedItems },
            { new: true }
        );
        if (!order) return res.status(404).send('Order not found');
        res.send(order);
    } catch (error) {
        res.status(400).send(error);
    }
});

// Deletar o pedido
router.delete('/order/:orderId', async (req, res) => {
    const { orderId } = req.params;
    try {
        const order = await Order.findOneAndDelete({ orderId });
        if (!order) return res.status(404).send('Order not found');
        res.send('Order deleted');
    } catch (error) {
        res.status(400).send(error);
    }
});

module.exports = router;
